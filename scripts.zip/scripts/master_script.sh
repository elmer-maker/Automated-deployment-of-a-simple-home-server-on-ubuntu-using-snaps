#!/bin/bash

cd scripts

chmod +x s.sh p.sh j.sh n.sh o.sh x.sh k.sh x2.sh r.sh a.sh f.sh

echo "Starting complete setup process..."

#echo "=== Step 0: Preparation... ==="
#./a.sh

echo "=== Step 1: Installing snap packages ==="
sudo ./s.sh

echo "=== Step 2: Configuring ports ==="
./p.sh

echo "=== Step 3: Configuring JWT secret ==="
./k.sh

echo "=== Step 4: Waiting for Nextcloud setup ==="
./n.sh

echo "=== Step 5: Configuring OnlyOffice connector ==="
./o.sh

echo "=== Step 6: Configuring shared storage for Jellyfin ==="
./j.sh

echo "=== Step 7: Connecting applications to the shared storage ==="
./r.sh

echo "=== Final check... ==="

./f.sh
echo "Setup completed!"
./x2.sh
read -p "Press ANY KEY to exit the installer."
