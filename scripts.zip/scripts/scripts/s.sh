#!/bin/bash
echo "Starting installation of necessary snap packages..."

# Install Nextcloud
sudo snap install nextcloud
if [ $? -ne 0 ]; then 
    echo "Error installing Nextcloud."
    exit 1
fi
echo "Nextcloud installed."

# Install Jellyfin
sudo snap install itrue-jellyfin
if [ $? -ne 0 ]; then 
    echo "Error installing itrue-jellyfin."
    exit 1
fi
echo "itrue-jellyfin installed."

# Install OnlyOffice Document Server
sudo snap install onlyoffice-ds
if [ $? -ne 0 ]; then 
    echo "Error installing onlyoffice-ds."
    exit 1
fi
echo "onlyoffice-ds installed."

echo "All snap packages successfully installed!"
