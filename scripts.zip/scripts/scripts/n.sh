#!/bin/bash
echo ""
echo "IMPORTANT: Nextcloud requires initial setup through web interface"
echo "Please open a web browser and go to: http://localhost"
echo "Complete the Nextcloud setup by creating an admin account"
echo ""
echo "If you need the JWT secret for OnlyOffice configuration, check /tmp/onlyoffice_secret.txt"
echo ""
./x.sh
read -p "After completing the Nextcloud setup in browser, press Enter to continue..."
