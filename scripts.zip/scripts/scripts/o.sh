#!/bin/bash
# Read the JWT secret from file

LOCAL_IP=$(hostname -I | awk '{print $1}')

if [ -f /tmp/onlyoffice_secret.txt ]; then
    ONLYOFFICE_SECRET=$(cat /tmp/onlyoffice_secret.txt)
else
    echo "Error: JWT secret file not found. Please run script3 first."
    exit 1
fi

echo "Installing and configuring OnlyOffice Connector application in Nextcloud..."

# 1. Install application (connector)
echo "Installing OnlyOffice Connector..."
sudo nextcloud.occ app:install onlyoffice
if [ $? -eq 0 ]; then
    echo "OnlyOffice Connector application installed."
else
    echo "Error installing application. It might already be installed."
fi

# 2. Set document server URL
echo "Setting OnlyOffice DS URL in Nextcloud..."
sudo nextcloud.occ config:app:set onlyoffice DocumentServerInternalUrl --value="http://127.0.0.1:8888"
sudo nextcloud.occ config:app:set onlyoffice DocumentServerUrl --value="http://$LOCAL_IP:8888" 

# 3. Set JWT secret

sudo nextcloud.occ config:app:set onlyoffice jwt_secret --value=$ONLYOFFICE_SECRET

sudo snap restart onlyoffice-ds
sudo snap restart nextcloud

echo "Nextcloud and OnlyOffice integration configured!"
echo "JWT Secret used: $ONLYOFFICE_SECRET"
