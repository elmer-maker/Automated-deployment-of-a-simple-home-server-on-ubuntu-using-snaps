#!/bin/bash
sudo snap restart nextcloud
sudo snap restart onlyoffice-ds
sudo snap restart itrue-jellyfin
