#!/bin/bash
xdg-open http://localhost
xdg-open http://localhost:8096
