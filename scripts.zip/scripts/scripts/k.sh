#!/bin/bash
# Generate random secret key for OnlyOffice
ONLYOFFICE_SECRET=$(openssl rand -hex 16)

echo "Configuring JWT secret for OnlyOffice DS..."


# Save secret to file for other scripts to use
echo "$ONLYOFFICE_SECRET" > /tmp/onlyoffice_secret.txt

# Set generated secret for ONLYOFFICE DS

sudo snap set onlyoffice-ds onlyoffice.jwt-secret="${ONLYOFFICE_SECRET}"

echo "JWT secret for OnlyOffice DS set."

# Restart OnlyOffice DS service to apply settings
echo "Restarting onlyoffice-ds..."
sudo snap restart onlyoffice-ds

echo "JWT configuration completed. Secret saved to /tmp/onlyoffice_secret.txt"
