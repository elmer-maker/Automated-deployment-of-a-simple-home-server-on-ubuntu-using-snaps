#!/bin/bash
echo = "Connecting Nextcloud to the removable media interface..."
sudo snap connect nextcloud:removable-media

echo = "Connecting Jellyfin to the removable media interface..."
sudo snap connect itrue-jellyfin:removable-media
