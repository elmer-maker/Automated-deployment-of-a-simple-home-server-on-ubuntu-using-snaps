#!/bin/bash
echo "Configuring external storage for Nextcloud..."

# Create the directory if it doesn't exist
echo "Creating /media/jellyfin_share directory..."
sudo mkdir -p /media/jellyfin_share



# Enable external storage app in Nextcloud
echo "Enabling external storage support in Nextcloud..."
sudo nextcloud.occ app:enable files_external

# Add the external storage mount point
echo "Adding external storage mount point..."
sudo nextcloud.occ files_external:create "Jellyfin Media" local null::null --config datadir=/media/jellyfin_share

echo "External storage configuration completed!"
echo "Storage mounted at: /media/jellyfin_share"
