#!/bin/bash

echo "Preparing the system..."
echo "Installing updates..."
sudo apt update
sudo apt upgrade
sudo apt install openssl
sudo apt autoremove

echo "Ready for installation!"

