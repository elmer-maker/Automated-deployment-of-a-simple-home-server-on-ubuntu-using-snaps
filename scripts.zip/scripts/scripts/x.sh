#!/bin/bash
xdg-open http://localhost
