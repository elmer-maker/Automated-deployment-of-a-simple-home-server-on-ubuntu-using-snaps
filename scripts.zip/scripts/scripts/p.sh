#!/bin/bash
echo "Configuring ports for OnlyOffice DS..."
sudo snap set onlyoffice-ds onlyoffice.ds-port=8888
echo "Port configuration completed."
